using ChargeSlot.Api.Enums;

namespace ChargeSlot.Api.Models
{
    /// <summary>SRS 1.5 ChargingStation - owner, location, approval, operational status.</summary>
    public class ChargingStation
    {
        public int Id { get; set; }
        public int OwnerUserId { get; set; }
        public Owner Owner { get; set; } = null!;

        public string Name { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string? Description { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }

        // Sơ đồ mặt bằng trạm sạc
        public string? LayoutImageUrl { get; set; }
        public decimal? LayoutWidth { get; set; }
        public decimal? LayoutHeight { get; set; }

        public ApprovalStatus ApprovalStatus { get; set; } = ApprovalStatus.Draft;
        public OperationalStatus OperationalStatus { get; set; } = OperationalStatus.Inactive;
        public DateTime? SubmittedAt { get; set; }
        public DateTime? ReviewedAt { get; set; }
        /// <summary>Admin Id (0) — không FK vì Admin config trong appsettings, không lưu DB.</summary>
        public int? ReviewedByUserId { get; set; }
        public string? AdminNote { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }

        public ICollection<StationImage> Images { get; set; } = new List<StationImage>();
        public ICollection<StationOperatingHours> OperatingHours { get; set; } = new List<StationOperatingHours>();
        public ICollection<ExtraService> ExtraServices { get; set; } = new List<ExtraService>();
        public ICollection<ChargingSlot> ChargingSlots { get; set; } = new List<ChargingSlot>();
    }
}
